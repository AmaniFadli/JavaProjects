import java.util.Scanner;

class Main{
  public static void main(String[] arg){
    Scanner input = new Scanner(System.in);
    int llarg, posicio, valor;

    VectorInt vi = new VectorInt();

    posicio = (int)(Math.random()*4);
    valor = (int)(Math.random()*20 + 1);
    
    if(vi.assignaValor(posicio,valor)){
      vi.mostrarVector();
    }
    else{
      System.out.println("SOBREPASA EL VECTOR");
    }

    System.out.println();
    System.out.println("ASSIGNACIÓ DE VALORS AL VECTOR");
    vi.assignaValorAleatori(10,1);
    vi.mostrarVector();

    System.out.println();

    System.out.println("ORDENACIÓ DEL VECTOR DE MEJOR A MAJOR");
    vi.ordenaVector();
    vi.mostrarVector();

    System.out.println();
    
    System.out.println("Selecciona una llargada del vector");
    llarg = input.nextInt();
    
    VectorInt vi2 = new VectorInt(llarg);

    posicio = (int)(Math.random()*llarg);
    valor = (int)(Math.random()*20 + 1);
    
    if(vi2.assignaValor(posicio,valor)){
      vi2.mostrarVector();
    }
    else{
      System.out.println("SOBREPASA EL VECTOR");
    }
    
    System.out.println();
    
    System.out.println("ASSIGNACIÓ DE VALORS AL VECTOR");
    vi2.assignaValorAleatori(10,1);
    vi2.mostrarVector();

    System.out.println();
    
    System.out.println("ORDENACIÓ DEL VECTOR DE MENOR A MAJOR");
    vi2.ordenaVector();
    vi2.mostrarVector();
    
  }
   
}