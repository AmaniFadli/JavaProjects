class VectorInt{
  int llargada = 5;
  int v[];

  // constructores
  public VectorInt(){
    v = new int[llargada];
  }
  
  public VectorInt(int newLlargada){
    v = new int[newLlargada];
  }

  // funciones
  public boolean assignaValor(int posicio, int valor){
    boolean verificar = false;
    
    if(posicio < v.length){
      v[posicio] = valor;
      verificar = true;
    }
    return verificar;
  }

  public int retornaValor(int posicio){
    int valor;
    
    if(posicio < llargada && posicio >= 0){
      
      valor = v[posicio];
    }
      
    else{
      valor = Integer.MIN_VALUE;
    }
    
    return valor;
  }
  
  public void mostrarVector(){
    for(int i = 0; i < v.length; i++){
      System.out.print(v[i] + " ");
    }
    System.out.println();
  }

  public void assignaValorAleatori(int interval, int inici){

    for(int i = 0; i < v.length; i++){
      
      do{
        v[i] = (int)(Math.random()*interval);
      }while(v[i] < inici);
      
    }
  }  

  public void ordenaVector(){
    boolean ordenat = false;
    int i = 1, aux = 0;
    
    while (ordenat == false){
      ordenat = true;
      
      for (int j=0; j<v.length-i; j++){
      
        if (v[j] > v[j+1]){
          aux = v[j];
          v[j] = v[j+1];
          v[j+1] = aux;
          ordenat = false;
        }
      }
      i++;
    }

  }
  
}