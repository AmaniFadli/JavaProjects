import java.util.*;

class Main {
  public static void main(String[] args) {
    LinkedList<String> cua = new LinkedList();
    Stack<String> pila = new Stack();

    cua.offer("c1");
    cua.offer("c2");
    cua.offer("c3");
    pila.push("cUrg");

    while(!pila.empty() || !cua.isEmpty()){
      System.out.print("Prosezando Cliente: ");
      
      if(!pila.empty()){
        System.out.println(pila.peek());
        cua.offer(pila.pop());
      } else {
        System.out.println(cua.peek());
        cua.removeFirst();
      }
    }
    
  }
}